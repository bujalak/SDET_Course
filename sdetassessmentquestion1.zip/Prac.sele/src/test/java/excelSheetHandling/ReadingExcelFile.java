package excelSheetHandling;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;

public class ReadingExcelFile {

	public static void main(String[] args) throws Exception {

		File file = new File("ExcelTask.xls");
		FileInputStream inputStream = new FileInputStream(file);
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = wb.getSheet("Sheet1");
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();

		for (int i = 0; i <= rowCount; i++) {
			int cellcount = sheet.getRow(i).getLastCellNum();

			for (int j = 0; j < cellcount; j++) {
				Cell cell = sheet.getRow(i).getCell(j);

				if (cell.getCellType() == CellType.NUMERIC) {
					System.out.print((int) cell.getNumericCellValue() + "\t");
				} else if (cell.getCellType() == CellType.STRING) {
					System.out.print(cell.getStringCellValue() + "\t");
				}
			}

			System.out.println();
		}

		// Don't forget to close the workbook and input stream after usage
		wb.close();
		inputStream.close();
		System.out.println();

	}
}
